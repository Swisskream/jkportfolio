import React from 'react';
import Recipes from './gf_index.js';
import './homepage.css';
import './gf_script.js';

function App() {
  return (
    <Recipes />
  );
}

export default App;
